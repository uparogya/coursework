EXTRACTION: https://www.ncei.noaa.gov/maps/grid-extract/
