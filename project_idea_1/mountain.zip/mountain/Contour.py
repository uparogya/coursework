import rasterio
import numpy as np
import matplotlib.pyplot as plt
from Elevation import Elevation
import sys


def smallestChange(start_vertex, goal_vertex, map_file):

    with rasterio.open(map_file) as src:
        elevation_data = src.read(1)

    minimum_elevation, maximum_elevation = np.min(elevation_data), np.max(elevation_data)
    grid_layout = elevation_data.copy()
    
    start_vertex_x, start_vertex_y = int(start_vertex[1]), int(start_vertex[0])
    goal_vertex_x, goal_vertex_y = int(goal_vertex[1]), int(goal_vertex[0])


    total_rows, total_cols = grid_layout.shape

    if start_vertex_x < 0 or goal_vertex_x < 0 or start_vertex_y < 0 or goal_vertex_y < 0 or start_vertex_x >= total_rows or goal_vertex_x >= total_rows or start_vertex_y >= total_cols or goal_vertex_y >= total_cols:
        print('Coordinates out of bounds! Max Range: ' + str(total_cols-1) + ',' + str(total_rows-1))
        quit()

    
    path = Elevation(grid_layout, (start_vertex_x, start_vertex_y), (goal_vertex_x, goal_vertex_y))
    lowest_changing_path_greedy = path.solve_greedy()
    lowest_changing_path_dijkstra = path.solve_dijkstra()

    x_coors_dijkstra = []
    y_coors_dijkstra = []
    for coordinate in lowest_changing_path_dijkstra:
        y_coors_dijkstra.append(coordinate[0])
        x_coors_dijkstra.append(coordinate[1])

    x_coors_greedy = []
    y_coors_greedy = []  
    for coordinate in lowest_changing_path_greedy:
        y_coors_greedy.append(coordinate[0])
        x_coors_greedy.append(coordinate[1])

    plt.figure(figsize=(10, 8))
    contour = plt.contour(elevation_data, levels=np.linspace(minimum_elevation, maximum_elevation, 10), cmap='inferno')
    plt.clabel(contour, inline=True, fontsize=8)
    plt.colorbar(contour, label='Elevation (m)')
    # plt.plot(x_coors_dijkstra, y_coors_dijkstra, color='red', linewidth=2, marker='o', markersize=1, label='Dijkstra Path')
    plt.plot(x_coors_greedy, y_coors_greedy, color='black', linewidth=2, marker='o', markersize=1, label='Greedy Path')
    # plt.scatter(x_coors_greedy[0], y_coors_greedy[0], color='green', s=100, zorder=5, label='Start Point')
    # plt.scatter(x_coors_greedy[-1], y_coors_greedy[-1], color='red', s=100, zorder=5, label='End Point')
    plt.legend()
    plt.show()

if __name__ == '__main__':

    maps = {
            0: ('Greeley - Colorado Springs - Gypsum','g_g_c.tiff'), # python Contour.py -start 10 50 -goal 133 0 -map 0
            1: ('Sagarmatha - Biratnagar - Kathmandu','s_b_k.tiff'), # python Contour.py -start 175 120 -goal 133 0 -map 1
            2: ('Hartford - Greenfield - Boston','h_g_b.tiff'), # python Contour.py -start 0 0 -goal 96 48 -map 2
            3: ('Half Switzerland','swiss.tiff'), # python Contour.py -start 0 0 -goal 110 60 -map 3
            4: ('Sample Set', 'downloaded_image.tiff'), # python Contour.py -start 0 0 -goal 170 20 -map 4
            5: ('Sample Set 2', 'im2.tiff') # python Contour.py -start 0 0 -goal 4 6 -map 5
        }

    if len(sys.argv) != 9:
        print('Usage python Project.py -start x y -goal x y -map map_num')
        quit()
    
    selection = int(sys.argv[8])
    
    if selection not in maps:
        print('Invalid option selected!')
        quit()

    selection = maps[selection][1]
    
    smallestChange((sys.argv[2],sys.argv[3]), (sys.argv[5],sys.argv[6]), selection)